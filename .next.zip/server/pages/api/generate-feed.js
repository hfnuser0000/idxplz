"use strict";
(() => {
var exports = {};
exports.id = 558;
exports.ids = [558];
exports.modules = {

/***/ 4582:
/***/ ((module) => {

module.exports = require("feed");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 6836:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
function handler(req, res) {
    const fs = __webpack_require__(7147);
    const Feed = (__webpack_require__(4582).Feed);
    const nameDataGenerator = __webpack_require__(2738);
    const baseKeywordsText = nameDataGenerator.generateData('').baseKeywordsText;
    function generateFeed(names, page) {
        const siteURL = 'https://printinix.com';
        const author = {
            name: "Printinix",
            email: "support@printinix.com",
            link: siteURL
        };
        const date = new Date;
        const feed = new Feed({
            title: `Printinix product list #${page}`,
            description: `Are you looking for name shirt? We have various designs of name printed on ${baseKeywordsText}... Check it now and pick your favorites!`,
            id: siteURL,
            link: siteURL,
            image: `https://cms.printinix.com/uploads/t_shirt_mockup_50b0640f9c.jpg`,
            favicon: `${siteURL}/logo-512x.png`,
            copyright: `All rights reserved ${date.getFullYear()}, Printinix`,
            updated: date,
            generator: "Feed for Node.js",
            feedLinks: {
                rss2: `${siteURL}/rss-feed/page-${page}.xml`
            },
            author
        });
        names.forEach((name)=>{
            const url = `${siteURL}/${name}`;
            const fullName = name.replaceAll('_', ' ').replaceAll('-', ' ').replaceAll('/', '');
            const nameData = nameDataGenerator.generateData(fullName);
            const description = nameData.description;
            feed.addItem({
                title: `${fullName} name ${nameData.keywordsText} - Printinix Custom Name Apparel`,
                id: url,
                link: url,
                description: description,
                content: description,
                author: [
                    author
                ],
                contributor: [
                    author
                ],
                date: new Date
            });
        });
        fs.writeFileSync(`./public/rss-feed/page-${page}.xml`, feed.rss2());
    }
    let names1 = fs.readFileSync('./data/names.txt').toString();
    names1 = names1.split('\n').map((name)=>{
        return name.trim().replaceAll('https://printinix.com/', '').replaceAll(' ', '-');
    }).filter((name)=>!!name
    );
    let response = '';
    for(let page1 = 1; page1 <= Math.ceil(names1.length / 60); ++page1){
        generateFeed(names1.slice((page1 - 1) * 60, page1 * 60), page1);
        response += `
            <a href="/rss-feed/page-${page1}.xml">Printinix product list #${page1}</a>
        `;
    }
    res.send(response);
// res.send('Stop it');
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [738], () => (__webpack_exec__(6836)));
module.exports = __webpack_exports__;

})();