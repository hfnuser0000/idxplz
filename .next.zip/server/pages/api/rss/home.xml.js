"use strict";
(() => {
var exports = {};
exports.id = 341;
exports.ids = [341];
exports.modules = {

/***/ 4582:
/***/ ((module) => {

module.exports = require("feed");

/***/ }),

/***/ 3361:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var feed__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4582);
/* harmony import */ var feed__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(feed__WEBPACK_IMPORTED_MODULE_0__);

function handler(req, res) {
    const names = `
        Marwa Alcock
        Elle-May Huynh
        Bernard Gaines
        Glenda Mcphee
        Zeynep Fenton
        Anam Piper
        Annie Johnston
        Bethany Gale
        Antonia Gross
        Iga Woods
        Rafe Silva
        August Sweet
    `.split('\n').map((name)=>{
        return name.trim().replaceAll(' ', '-');
    }).filter((name)=>!!name
    ).map((name)=>name
    );
    const siteURL = 'https://9nick.com';
    const author = {
        name: "9nick",
        email: "support@9nick.com",
        link: siteURL
    };
    const date = new Date;
    const feed = new feed__WEBPACK_IMPORTED_MODULE_0__.Feed({
        title: "9nick",
        description: "",
        id: siteURL,
        link: siteURL,
        image: `https://cms.printinix.com/uploads/t_shirt_mockup_50b0640f9c.jpg`,
        favicon: `${siteURL}/logo-512x.png`,
        copyright: `All rights reserved ${date.getFullYear()}, 9nick`,
        updated: date,
        generator: "Feed for Node.js",
        feedLinks: {
            rss2: `${siteURL}/rss/home.xml`
        },
        author
    });
    names.forEach((name)=>{
        const url = `${siteURL}/${name}`;
        const fullName = name.replaceAll('_', ' ').replaceAll('-', ' ').replaceAll('/', '');
        feed.addItem({
            title: fullName + ' shirts',
            id: url,
            link: url,
            description: `Products for ${fullName}`,
            content: `Products for ${fullName}`,
            author: [
                author
            ],
            contributor: [
                author
            ],
            date: new Date
        });
    });
    res.send(feed.rss2());
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3361));
module.exports = __webpack_exports__;

})();