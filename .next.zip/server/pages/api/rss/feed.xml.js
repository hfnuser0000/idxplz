"use strict";
(() => {
var exports = {};
exports.id = 949;
exports.ids = [949];
exports.modules = {

/***/ 4582:
/***/ ((module) => {

module.exports = require("feed");

/***/ }),

/***/ 514:
/***/ ((module) => {

module.exports = require("knex");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 5810:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const knex = __webpack_require__(514);
const data = {
};
function connect(dbLocation) {
    if (!data[dbLocation]) {
        data[dbLocation] = knex({
            client: 'sqlite3',
            connection: {
                filename: dbLocation
            },
            useNullAsDefault: true
        });
    }
    return data[dbLocation];
}
module.exports = {
    connect
};


/***/ }),

/***/ 7749:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
function handler(req, res) {
    const fs = __webpack_require__(7147);
    const Feed = (__webpack_require__(4582).Feed);
    const knexClient = __webpack_require__(5810);
    const nameDB = knexClient.connect('../name-db/names.db');
    const nameDataGenerator = __webpack_require__(2738);
    const { RNG , shuffle  } = __webpack_require__(8214);
    const names = `
        Marwa Alcock
        Elle-May Huynh
        Bernard Gaines
        Glenda Mcphee
        Zeynep Fenton
        Anam Piper
        Annie Johnston
        Bethany Gale
        Antonia Gross
        Iga Woods
        Rafe Silva
        August Sweet
    `.split('\n').map((name)=>{
        return name.trim().replaceAll(' ', '-');
    }).filter((name)=>!!name
    ).map((name)=>name
    );
    const siteURL = 'https://9nick.com';
    const author = {
        name: "9nick",
        email: "support@9nick.com",
        link: siteURL
    };
    const date = new Date;
    const feed = new Feed({
        title: "9nick",
        description: "",
        id: siteURL,
        link: siteURL,
        image: `https://cms.printinix.com/uploads/t_shirt_mockup_50b0640f9c.jpg`,
        favicon: `${siteURL}/logo-512x.png`,
        copyright: `All rights reserved ${date.getFullYear()}, 9nick`,
        updated: date,
        generator: "Feed for Node.js",
        feedLinks: {
            rss2: `${siteURL}/rss/home.xml`
        },
        author
    });
    names.forEach((name)=>{
        const url = `${siteURL}/${name}`;
        const fullName = name.replaceAll('_', ' ').replaceAll('-', ' ').replaceAll('/', '');
        feed.addItem({
            title: fullName + ' shirts',
            id: url,
            link: url,
            description: `Products for ${fullName}`,
            content: `Products for ${fullName}`,
            author: [
                author
            ],
            contributor: [
                author
            ],
            date: new Date
        });
    });
    res.send(feed.rss2());
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [738], () => (__webpack_exec__(7749)));
module.exports = __webpack_exports__;

})();