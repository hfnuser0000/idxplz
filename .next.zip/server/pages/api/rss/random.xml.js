"use strict";
(() => {
var exports = {};
exports.id = 733;
exports.ids = [733];
exports.modules = {

/***/ 4582:
/***/ ((module) => {

module.exports = require("feed");

/***/ }),

/***/ 514:
/***/ ((module) => {

module.exports = require("knex");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 5810:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const knex = __webpack_require__(514);
const data = {
};
function connect(dbLocation) {
    if (!data[dbLocation]) {
        data[dbLocation] = knex({
            client: 'sqlite3',
            connection: {
                filename: dbLocation
            },
            useNullAsDefault: true
        });
    }
    return data[dbLocation];
}
module.exports = {
    connect
};


/***/ }),

/***/ 2615:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
async function handler(req, res) {
    const fs = __webpack_require__(7147);
    const Feed = (__webpack_require__(4582).Feed);
    const knexClient = __webpack_require__(5810);
    const nameDB = knexClient.connect('../name-db/names.db');
    const nameDataGenerator = __webpack_require__(2738);
    const { RNG , shuffle  } = __webpack_require__(8214);
    const baseKeywordsText = nameDataGenerator.generateData('').baseKeywordsText;
    const nameCount = 27306287;
    const randomNames = [];
    while(randomNames.length < 60){
        const randomID = 1 + Math.floor(Math.random() * nameCount);
        const randomName = (await nameDB('name').select().where({
            id: randomID
        }))[0].name;
        if (randomName.match(/^[A-Za-z]+$/g) && !randomNames.includes(randomName)) {
            randomNames.push(randomName);
        }
    }
    function generateFeed(names) {
        const siteURL = 'https://printinix.com';
        const author = {
            name: "Printinix",
            email: "support@printinix.com",
            link: siteURL
        };
        const date = new Date;
        const feed = new Feed({
            title: `Printinix random products`,
            description: `Are you looking for name shirt? We have various designs of name printed on ${baseKeywordsText}... Check it now and pick your favorites!`,
            id: siteURL,
            link: siteURL,
            image: `https://cms.printinix.com/uploads/t_shirt_mockup_50b0640f9c.jpg`,
            favicon: `${siteURL}/logo-512x.png`,
            copyright: `All rights reserved ${date.getFullYear()}, Printinix`,
            updated: date,
            generator: "Feed for Node.js",
            feedLinks: {
                rss2: `${siteURL}/api/rss/random.xml`
            },
            author
        });
        names.forEach((name)=>{
            const url = `${siteURL}/${name}`;
            const fullName = name.replaceAll('_', ' ').replaceAll('-', ' ').replaceAll('/', '');
            const nameData = nameDataGenerator.generateData(fullName);
            const description = nameData.description;
            feed.addItem({
                title: `${fullName} name ${nameData.keywordsText} - Printinix Custom Name Apparel`,
                id: url,
                link: url,
                description: description,
                content: description,
                author: [
                    author
                ],
                contributor: [
                    author
                ],
                date: new Date
            });
        });
        return feed.rss2();
    }
    res.send(generateFeed(randomNames));
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [738], () => (__webpack_exec__(2615)));
module.exports = __webpack_exports__;

})();