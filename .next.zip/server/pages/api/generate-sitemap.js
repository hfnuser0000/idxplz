"use strict";
(() => {
var exports = {};
exports.id = 150;
exports.ids = [150];
exports.modules = {

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 7570:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_0__);

function handler(req, res) {
    let offset = req.query.offset;
    if (!offset) {
        return res.status(400).send('offset is required.');
    }
    offset = +offset;
    const date = new Date;
    const prefix0 = (s)=>{
        return ('000' + s).slice(-2);
    };
    const dd = prefix0(date.getDate());
    const mm = prefix0(date.getMonth() + 1);
    const yy = prefix0(date.getFullYear());
    const nameList = fs__WEBPACK_IMPORTED_MODULE_0___default().readFileSync('./data/names.txt').toString().split('\n');
    const sitemapData = nameList.slice(offset, offset + 50000).map((name)=>{
        const formatted = name.replaceAll(' ', '-');
        return `https://printinix.com/${formatted}`;
    }).join('\n');
    let filename = `sitemap-${yy}${mm}${dd}.txt`;
    let count = 1;
    while(fs__WEBPACK_IMPORTED_MODULE_0___default().existsSync('./public/' + filename)){
        filename = `sitemap-${yy}${mm}${dd}-${count}.txt`;
        count++;
    }
    fs__WEBPACK_IMPORTED_MODULE_0___default().writeFileSync(`./public/${filename}`, sitemapData);
    return res.send(`
        <a href="/${filename}">Sitemap</a>
    `);
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7570));
module.exports = __webpack_exports__;

})();