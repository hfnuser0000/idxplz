"use strict";
(() => {
var exports = {};
exports.id = 219;
exports.ids = [219];
exports.modules = {

/***/ 1757:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const crypto = __webpack_require__(6113);
const { RNG , shuffle  } = __webpack_require__(1517);
const md5 = (content)=>{
    return crypto.createHash('md5').update(content).digest('hex');
};
const generateData = (name)=>{
    // const baseKeywords      = ['T shirts', 'Hoodies', 'Sweatshirts', 'Tank Tops', 'Mugs'];
    const baseKeywords = [
        'T-shirts'
    ];
    const keywords = shuffle(name, JSON.parse(JSON.stringify(baseKeywords)));
    const shortKeywords = keywords.slice(0, 4);
    const baseKeywordsText = baseKeywords.join(', ');
    const keywordsText = keywords.join(', ');
    const shortKeywordsText = shortKeywords.join(', ');
    const siteDescription = `Are you looking for a custom name shirt? We have various designs of custom name printed on ${baseKeywordsText}. Check it now and pick your favorites!`;
    const description = `Are you looking for ${name} custom name shirt? We have various designs of custom name ${name} printed on ${keywordsText}. Check it now and pick your favorites!`;
    return {
        siteDescription,
        description,
        baseKeywordsText,
        keywordsText,
        shortKeywordsText
    };
};
module.exports = {
    generateData
};


/***/ }),

/***/ 1517:
/***/ ((module) => {


function RNG(seed_0) {
    function xmur3(str) {
        for(var i = 0, h = 1779033703 ^ str.length; i < str.length; i++){
            h = Math.imul(h ^ str.charCodeAt(i), 3432918353);
            h = h << 13 | h >>> 19;
        }
        return function() {
            h = Math.imul(h ^ h >>> 16, 2246822507);
            h = Math.imul(h ^ h >>> 13, 3266489909);
            return (h ^= h >>> 16) >>> 0;
        };
    }
    function mulberry32(a) {
        return function() {
            var t = a += 1831565813;
            t = Math.imul(t ^ t >>> 15, t | 1);
            t ^= t + Math.imul(t ^ t >>> 7, t | 61);
            return ((t ^ t >>> 14) >>> 0) / 4294967296;
        };
    }
    function sfc32(a, b, c, d) {
        return function() {
            a >>>= 0;
            b >>>= 0;
            c >>>= 0;
            d >>>= 0;
            var t = a + b | 0;
            a = b ^ b >>> 9;
            b = c + (c << 3) | 0;
            c = c << 21 | c >>> 11;
            d = d + 1 | 0;
            t = t + d | 0;
            c = c + t | 0;
            return (t >>> 0) / 4294967296;
        };
    }
    // Create xmur3 state:
    var seed = xmur3(seed_0);
    // Output four 32-bit hashes to provide the seed for sfc32.
    var rand = sfc32(seed(), seed(), seed(), seed());
    // Output one 32-bit hash to provide the seed for mulberry32.
    var rand = mulberry32(seed());
    return rand;
}
function shuffle(seed, array) {
    let currentIndex = array.length, randomIndex;
    const rand = RNG(seed);
    // While there remain elements to shuffle...
    while(currentIndex != 0){
        // Pick a remaining element...
        randomIndex = Math.floor(rand() * currentIndex);
        currentIndex--;
        // And swap it with the current element.
        [array[currentIndex], array[randomIndex]] = [
            array[randomIndex],
            array[currentIndex]
        ];
    }
    return array;
}
module.exports = {
    RNG,
    shuffle
};


/***/ }),

/***/ 6406:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "default": () => (/* binding */ ShopPage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1614);
/* harmony import */ var _components_collection_heading__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9179);
/* harmony import */ var _components_card__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3352);
/* harmony import */ var _components_product_card__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1542);
/* harmony import */ var _components_card_collection__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7347);
/* harmony import */ var core_image_version__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2073);









// export async function getStaticProps(context) {
async function getServerSideProps(context) {
    const knexClient = __webpack_require__(6907);
    const nameDB = knexClient.connect('../name-db/names.db');
    const nameDataGenerator = __webpack_require__(1757);
    const { RNG , shuffle  } = __webpack_require__(1517);
    const { slug  } = context.params;
    if (slug == undefined) {
        return {
            redirect: {
                destination: '/',
                permanent: false
            }
        };
    }
    const name = slug.replaceAll('_', ' ').replaceAll('-', ' ');
    const nameData = nameDataGenerator.generateData(name);
    const url = `https://printinix.com/${slug}`;
    const description = nameData.description;
    const getProductHref = (sku)=>{
        return `https://shop.printinix.com/product/${sku}?customname=${encodeURIComponent(name)}`;
    // return '/maintenance';
    };
    const getProductImageURL = (sku)=>{
        return `https://cdn.printinix.com/mockup-image/${sku}---${encodeURIComponent(name)}.jpg?v=${(0,core_image_version__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)()}&scale=0.4`;
    };
    let products = [
        {
            title: 'In Case Of Emergency My Blood Type Is Custom Name T-shirt',
            href: getProductHref('my-blood-type-is-custom-name-t-shirt'),
            imageURL: getProductImageURL('my-blood-type-is-custom-name-t-shirt'),
            price: 15.95
        },
        {
            title: "It's A Custom Name Thing You Wouldn't Understand T-shirt",
            href: getProductHref('you-wouldnt-understand-custom-name-t-shirt'),
            imageURL: getProductImageURL('you-wouldnt-understand-custom-name-t-shirt'),
            price: 15.95
        },
        {
            title: "Genuine & Trusted Custom Name 100% Original High Quality T-shirt",
            href: getProductHref('genuine-and-trusted-custom-name-t-shirt'),
            imageURL: getProductImageURL('genuine-and-trusted-custom-name-t-shirt'),
            price: 15.95
        },
        {
            title: "If Custom Name Can't Fix It We're All Screwed T-shirt",
            href: getProductHref('if-custom-name-cant-fix-it-we-re-all-screwed-t-shirt'),
            imageURL: getProductImageURL('if-custom-name-cant-fix-it-we-re-all-screwed-t-shirt'),
            price: 15.95
        },
        {
            title: "The Legend Is Alive Custom Name An Endless Legend T-shirt",
            href: getProductHref('the-legend-is-alive-custom-name-an-endless-legend-t-shirt'),
            imageURL: getProductImageURL('the-legend-is-alive-custom-name-an-endless-legend-t-shirt'),
            price: 15.95
        },
        {
            title: "Team Custom Name Life Time Member Legend T-shirt",
            href: getProductHref('team-custom-name-life-time-member-legend-t-shirt'),
            imageURL: getProductImageURL('team-custom-name-life-time-member-legend-t-shirt'),
            price: 15.95
        },
        {
            title: "Custom Name Cool Awesome Man Nutrition Facts T-shirt",
            href: getProductHref('custom-name-cool-awesome-man-nutrition-facts-t-shirt'),
            imageURL: getProductImageURL('custom-name-cool-awesome-man-nutrition-facts-t-shirt'),
            price: 15.95
        },
        {
            title: "Custom Name Retro T-shirt",
            href: getProductHref('custom-name-retro-t-shirt'),
            imageURL: getProductImageURL('custom-name-retro-t-shirt'),
            price: 15.95
        },
        {
            title: "Never Underestimate The Power Of A Custom Name T-shirt",
            href: getProductHref('never-underestimate-the-power-of-a-custom-name-t-shirt'),
            imageURL: getProductImageURL('never-underestimate-the-power-of-a-custom-name-t-shirt'),
            price: 15.95
        },
        {
            title: "Don't Mess With Custom Name You Get Jurasskicked T-shirt",
            href: getProductHref('dont-mess-with-custom-name-you-get-jurasskicked-t-shirt'),
            imageURL: getProductImageURL('dont-mess-with-custom-name-you-get-jurasskicked-t-shirt'),
            price: 15.95
        },
        {
            title: "I Am A Dirty Mind Caring Friend Funny Custom Name T-shirt",
            href: getProductHref('i-am-a-dirty-mind-caring-friend-funny-custom-name-t-shirt'),
            imageURL: getProductImageURL('i-am-a-dirty-mind-caring-friend-funny-custom-name-t-shirt'),
            price: 15.95
        },
        {
            title: "I Am A Brave Heart Filthy Mouth Funny Custom Name T-shirt",
            href: getProductHref('i-am-a-brave-heart-filthy-mouth-funny-custom-name-t-shirt'),
            imageURL: getProductImageURL('i-am-a-brave-heart-filthy-mouth-funny-custom-name-t-shirt'),
            price: 15.95
        },
        {
            title: "Dad The Man The Myth The Legend Custom Name T-shirt",
            href: getProductHref('dad-the-man-the-myth-the-legend-custom-name-t-shirt'),
            imageURL: getProductImageURL('dad-the-man-the-myth-the-legend-custom-name-t-shirt'),
            price: 15.95
        }, 
    ];
    let randomNames = [];
    shuffle(name, products);
    products.forEach((product)=>{
        product.title = product.title.replace('Custom Name', name);
    });
    // const nameCount = await nameDB('name').count();
    const nameCount = 27306287;
    while(randomNames.length < 60){
        const randomID = 1 + Math.floor(Math.random() * nameCount);
        const randomName = (await nameDB('name').select().where({
            id: randomID
        }))[0].name;
        if (randomName.match(/^[A-Za-z]+$/g) && !randomNames.includes(randomName)) {
            randomNames.push(randomName);
        }
    }
    return {
        props: {
            slug,
            name,
            url,
            description,
            products: products.slice(0, 12),
            randomNames
        }
    };
}
// export async function getStaticPaths() {
//     return {
//         // paths: names,
//         paths: [],
//         fallback: 'blocking'
//     }
// }
const Container = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
    componentId: "sc-10c07214-0"
})`
    .card {
        position: relative;
    }

    .description-card {
        background: #7771;
        margin: 2rem 0;

        > div {
            position: relative;
        }
    }

    .random-names {
        // background: #7771;
        margin: 2rem 0;

        display: flex;
        flex-wrap: wrap;

        > div {
            position: relative;
        }

        p {
            width: 100%;
        }

        a {
            display: inline-block;
            background: #7771;
            padding: .5rem 1rem;
            margin: .5rem;
        }
    }
`;
function ShopPage(props) {
    let { slug , name , url , description , products , randomNames  } = props;
    const thumbnailURL = products[0].imageURL;
    const title = `${name} name T-shirts, Sweatshirts, Sweaters, Tank Tops, Hoodies`;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        title: title,
        description: description,
        url: url,
        thumbnail: thumbnailURL,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_collection_heading__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: "Custom name t-shirts for "
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: name
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_card__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    className: "description-card",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: description
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_card_collection__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    gap: "1rem",
                    children: products.map((product, idx)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product_card__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            title: product.title,
                            hoverTitle: "View product",
                            href: product.href,
                            price: product.price,
                            imageURL: product.imageURL
                        }, idx)
                    )
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "random-names",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            style: {
                                fontWeight: '400'
                            },
                            children: "Random names: "
                        }),
                        randomNames.map((randomName, idx)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: '/' + encodeURIComponent(randomName),
                                prefetch: false,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    children: randomName
                                })
                            }, `${name}#${idx}`)
                        )
                    ]
                })
            ]
        })
    }));
};


/***/ }),

/***/ 9463:
/***/ ((module) => {

module.exports = require("@hookstate/core");

/***/ }),

/***/ 514:
/***/ ((module) => {

module.exports = require("knex");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 9816:
/***/ ((module) => {

module.exports = require("styled-jsx/style");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,61,152,614,662], () => (__webpack_exec__(6406)));
module.exports = __webpack_exports__;

})();