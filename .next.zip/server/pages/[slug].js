"use strict";
(() => {
var exports = {};
exports.id = 219;
exports.ids = [219];
exports.modules = {

/***/ 3352:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Card)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const { default: styled  } = __webpack_require__(7518);
const hoverCSS = `
    :hover {
        border-color: #888;
    }
`;
const Container = styled.div`
    // border-radius: .5rem;
    border: 2px solid transparent;
    ${(props)=>props.hoverEffect ? hoverCSS : ''
}
    ${(props)=>props.background ? 'background: ' + props.background + ';' : ''
}
    ${(props)=>props.ratio ? 'padding-top: ' + 1 / props.ratio * 100 + '%;' : 'padding: 2rem;'
}
    position: relative;
    overflow: hidden;

    > * {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
    }
`;
function Card(props) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Container, {
        ...props
    }));
};


/***/ }),

/***/ 6907:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const knex = __webpack_require__(514);
const data = {
};
function connect(dbLocation) {
    if (!data[dbLocation]) {
        data[dbLocation] = knex({
            client: 'sqlite3',
            connection: {
                filename: dbLocation
            },
            useNullAsDefault: true
        });
    }
    return data[dbLocation];
}
module.exports = {
    connect
};


/***/ }),

/***/ 1757:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const crypto = __webpack_require__(6113);
const { RNG , shuffle  } = __webpack_require__(1517);
const md5 = (content)=>{
    return crypto.createHash('md5').update(content).digest('hex');
};
const generateData = (name)=>{
    // const baseKeywords      = ['T shirts', 'Hoodies', 'Sweatshirts', 'Tank Tops', 'Mugs'];
    const baseKeywords = [
        'T-shirts'
    ];
    const keywords = shuffle(name, JSON.parse(JSON.stringify(baseKeywords)));
    const shortKeywords = keywords.slice(0, 4);
    const baseKeywordsText = baseKeywords.join(', ');
    const keywordsText = keywords.join(', ');
    const shortKeywordsText = shortKeywords.join(', ');
    const siteDescription = `Are you looking for a custom name shirt? We have various designs of custom name printed on ${baseKeywordsText}. Check it now and pick your favorites!`;
    const description = `Are you looking for ${name} custom name shirt? We have various designs of custom name ${name} printed on ${keywordsText}. Check it now and pick your favorites!`;
    return {
        siteDescription,
        description,
        baseKeywordsText,
        keywordsText,
        shortKeywordsText
    };
};
module.exports = {
    generateData
};


/***/ }),

/***/ 1517:
/***/ ((module) => {


function RNG(seed_0) {
    function xmur3(str) {
        for(var i = 0, h = 1779033703 ^ str.length; i < str.length; i++){
            h = Math.imul(h ^ str.charCodeAt(i), 3432918353);
            h = h << 13 | h >>> 19;
        }
        return function() {
            h = Math.imul(h ^ h >>> 16, 2246822507);
            h = Math.imul(h ^ h >>> 13, 3266489909);
            return (h ^= h >>> 16) >>> 0;
        };
    }
    function mulberry32(a) {
        return function() {
            var t = a += 1831565813;
            t = Math.imul(t ^ t >>> 15, t | 1);
            t ^= t + Math.imul(t ^ t >>> 7, t | 61);
            return ((t ^ t >>> 14) >>> 0) / 4294967296;
        };
    }
    function sfc32(a, b, c, d) {
        return function() {
            a >>>= 0;
            b >>>= 0;
            c >>>= 0;
            d >>>= 0;
            var t = a + b | 0;
            a = b ^ b >>> 9;
            b = c + (c << 3) | 0;
            c = c << 21 | c >>> 11;
            d = d + 1 | 0;
            t = t + d | 0;
            c = c + t | 0;
            return (t >>> 0) / 4294967296;
        };
    }
    // Create xmur3 state:
    var seed = xmur3(seed_0);
    // Output four 32-bit hashes to provide the seed for sfc32.
    var rand = sfc32(seed(), seed(), seed(), seed());
    // Output one 32-bit hash to provide the seed for mulberry32.
    var rand = mulberry32(seed());
    return rand;
}
function shuffle(seed, array) {
    let currentIndex = array.length, randomIndex;
    const rand = RNG(seed);
    // While there remain elements to shuffle...
    while(currentIndex != 0){
        // Pick a remaining element...
        randomIndex = Math.floor(rand() * currentIndex);
        currentIndex--;
        // And swap it with the current element.
        [array[currentIndex], array[randomIndex]] = [
            array[randomIndex],
            array[currentIndex]
        ];
    }
    return array;
}
module.exports = {
    RNG,
    shuffle
};


/***/ }),

/***/ 9039:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ShopPage),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./components/layout.jsx + 6 modules
var layout = __webpack_require__(990);
// EXTERNAL MODULE: ./components/collection-heading.jsx
var collection_heading = __webpack_require__(9179);
// EXTERNAL MODULE: ./components/card.jsx
var card = __webpack_require__(3352);
// EXTERNAL MODULE: ./components/image.jsx
var components_image = __webpack_require__(6607);
;// CONCATENATED MODULE: ./components/product-card.jsx





const Container = external_styled_components_default().div.withConfig({
    componentId: "sc-dcccf342-0"
})`
    position: relative;
    img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        transition: .2s;
    }
    :hover {
        img {
            transform: scale(1.1);
        }
    }

    .card {
        width: 100%;
        background: #7771;
    }

    .product {
        display: flex;
        justify-content: center;
        align-items: center;
        text-align: center;
        background: transparent;
        font-weight: bold;
        font-size: 2rem;
        color: transparent;
        transition: .2s;

        :hover {
            background: #262d24bf;
            color: white;
        }
    }

    .product-title {
        color: #555;
        font-weight: 400;
        display: flex;
        justify-content: center;
        align-items: center;
        text-align: center;
        margin-top: 1rem;
    }

    .price {
        display: block;
        text-align: center;
    }
`;
function ProductCard(props) {
    const { title ="" , hoverTitle , href ="#" , imageURL , ratio =1 , price  } = props;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Container, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(card/* default */.Z, {
                className: "card",
                ratio: ratio,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: imageURL,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: imageURL,
                                alt: title
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: href,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "product",
                            children: hoverTitle
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                className: "product-title",
                href: "#",
                children: title
            }),
            price && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                className: "price",
                href: "#",
                children: [
                    "only $",
                    price
                ]
            })
        ]
    }));
};

// EXTERNAL MODULE: ./components/grid.jsx
var grid = __webpack_require__(4663);
;// CONCATENATED MODULE: ./components/card-collection.jsx


const gridCSS = `
    grid-template-columns: 1fr 1fr 1fr 1fr;
    @media screen and (max-width: 1200px) {
        grid-template-columns: 1fr 1fr 1fr;
    }
    @media screen and (max-width: 800px) {
        grid-template-columns: 1fr 1fr;
    }
    @media screen and (max-width: 500px) {
        grid-template-columns: 1fr;
    }
`;
function CardCollection(props) {
    return(/*#__PURE__*/ jsx_runtime_.jsx(grid/* default */.Z, {
        ...props,
        css: gridCSS
    }));
};

;// CONCATENATED MODULE: ./core/image-version.js
const version = 1;
function ImageVersion() {
    return version;
};

;// CONCATENATED MODULE: ./pages/[slug].jsx









// export async function getStaticProps(context) {
async function getServerSideProps(context) {
    const knexClient = __webpack_require__(6907);
    const nameDB = knexClient.connect('../name-db/names.db');
    const nameDataGenerator = __webpack_require__(1757);
    const { RNG , shuffle  } = __webpack_require__(1517);
    const { slug  } = context.params;
    if (slug == undefined) {
        return {
            redirect: {
                destination: '/',
                permanent: false
            }
        };
    }
    const name = slug.replaceAll('_', ' ').replaceAll('-', ' ');
    const nameData = nameDataGenerator.generateData(name);
    const url = `https://printinix.com/${slug}`;
    const description = nameData.description;
    const getProductHref = (sku)=>{
        return `https://shop.printinix.com/product/${sku}?customname=${encodeURIComponent(name)}`;
    // return '/maintenance';
    };
    const getProductImageURL = (sku)=>{
        return `https://cdn.printinix.com/mockup-image/${sku}---${encodeURIComponent(name)}.jpg?v=${ImageVersion()}&scale=0.4`;
    };
    let products = [
        {
            title: 'In Case Of Emergency My Blood Type Is Custom Name T-shirt',
            href: getProductHref('my-blood-type-is-custom-name-t-shirt'),
            imageURL: getProductImageURL('my-blood-type-is-custom-name-t-shirt'),
            price: 15.95
        },
        {
            title: "It's A Custom Name Thing You Wouldn't Understand T-shirt",
            href: getProductHref('you-wouldnt-understand-custom-name-t-shirt'),
            imageURL: getProductImageURL('you-wouldnt-understand-custom-name-t-shirt'),
            price: 15.95
        },
        {
            title: "Genuine & Trusted Custom Name 100% Original High Quality T-shirt",
            href: getProductHref('genuine-and-trusted-custom-name-t-shirt'),
            imageURL: getProductImageURL('genuine-and-trusted-custom-name-t-shirt'),
            price: 15.95
        },
        {
            title: "If Custom Name Can't Fix It We're All Screwed T-shirt",
            href: getProductHref('if-custom-name-cant-fix-it-we-re-all-screwed-t-shirt'),
            imageURL: getProductImageURL('if-custom-name-cant-fix-it-we-re-all-screwed-t-shirt'),
            price: 15.95
        },
        {
            title: "The Legend Is Alive Custom Name An Endless Legend T-shirt",
            href: getProductHref('the-legend-is-alive-custom-name-an-endless-legend-t-shirt'),
            imageURL: getProductImageURL('the-legend-is-alive-custom-name-an-endless-legend-t-shirt'),
            price: 15.95
        },
        {
            title: "Team Custom Name Life Time Member Legend T-shirt",
            href: getProductHref('team-custom-name-life-time-member-legend-t-shirt'),
            imageURL: getProductImageURL('team-custom-name-life-time-member-legend-t-shirt'),
            price: 15.95
        },
        {
            title: "Custom Name Cool Awesome Man Nutrition Facts T-shirt",
            href: getProductHref('custom-name-cool-awesome-man-nutrition-facts-t-shirt'),
            imageURL: getProductImageURL('custom-name-cool-awesome-man-nutrition-facts-t-shirt'),
            price: 15.95
        },
        {
            title: "Custom Name Retro T-shirt",
            href: getProductHref('custom-name-retro-t-shirt'),
            imageURL: getProductImageURL('custom-name-retro-t-shirt'),
            price: 15.95
        },
        {
            title: "Never Underestimate The Power Of A Custom Name T-shirt",
            href: getProductHref('never-underestimate-the-power-of-a-custom-name-t-shirt'),
            imageURL: getProductImageURL('never-underestimate-the-power-of-a-custom-name-t-shirt'),
            price: 15.95
        },
        {
            title: "Don't Mess With Custom Name You Get Jurasskicked T-shirt",
            href: getProductHref('dont-mess-with-custom-name-you-get-jurasskicked-t-shirt'),
            imageURL: getProductImageURL('dont-mess-with-custom-name-you-get-jurasskicked-t-shirt'),
            price: 15.95
        },
        {
            title: "I Am A Dirty Mind Caring Friend Funny Custom Name T-shirt",
            href: getProductHref('i-am-a-dirty-mind-caring-friend-funny-custom-name-t-shirt'),
            imageURL: getProductImageURL('i-am-a-dirty-mind-caring-friend-funny-custom-name-t-shirt'),
            price: 15.95
        },
        {
            title: "I Am A Brave Heart Filthy Mouth Funny Custom Name T-shirt",
            href: getProductHref('i-am-a-brave-heart-filthy-mouth-funny-custom-name-t-shirt'),
            imageURL: getProductImageURL('i-am-a-brave-heart-filthy-mouth-funny-custom-name-t-shirt'),
            price: 15.95
        },
        {
            title: "Dad The Man The Myth The Legend Custom Name T-shirt",
            href: getProductHref('dad-the-man-the-myth-the-legend-custom-name-t-shirt'),
            imageURL: getProductImageURL('dad-the-man-the-myth-the-legend-custom-name-t-shirt'),
            price: 15.95
        }, 
    ];
    let randomNames = [];
    shuffle(name, products);
    products.forEach((product)=>{
        product.title = product.title.replace('Custom Name', name);
    });
    // const nameCount = await nameDB('name').count();
    const nameCount = 27306287;
    while(randomNames.length < 60){
        const randomID = 1 + Math.floor(Math.random() * nameCount);
        const randomName = (await nameDB('name').select().where({
            id: randomID
        }))[0].name;
        if (randomName.match(/^[A-Za-z]+$/g) && !randomNames.includes(randomName)) {
            randomNames.push(randomName);
        }
    }
    return {
        props: {
            slug,
            name,
            url,
            description,
            products: products.slice(0, 12),
            randomNames
        }
    };
}
// export async function getStaticPaths() {
//     return {
//         // paths: names,
//         paths: [],
//         fallback: 'blocking'
//     }
// }
const _slug_Container = external_styled_components_default().div.withConfig({
    componentId: "sc-10c07214-0"
})`
    .card {
        position: relative;
    }

    .description-card {
        background: #7771;
        margin: 2rem 0;

        > div {
            position: relative;
        }
    }

    .random-names {
        // background: #7771;
        margin: 2rem 0;

        display: flex;
        flex-wrap: wrap;

        > div {
            position: relative;
        }

        p {
            width: 100%;
        }

        a {
            display: inline-block;
            background: #7771;
            padding: .5rem 1rem;
            margin: .5rem;
        }
    }
`;
function ShopPage(props) {
    let { slug , name , url , description , products , randomNames  } = props;
    const thumbnailURL = products[0].imageURL;
    const title = `${name} name T-shirts, Sweatshirts, Sweaters, Tank Tops, Hoodies`;
    return(/*#__PURE__*/ jsx_runtime_.jsx(layout/* default */.Z, {
        title: title,
        description: description,
        url: url,
        thumbnail: thumbnailURL,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(_slug_Container, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(collection_heading/* default */.Z, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "Custom name t-shirts for "
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: name
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(card/* default */.Z, {
                    className: "description-card",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: description
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(CardCollection, {
                    gap: "1rem",
                    children: products.map((product, idx)=>/*#__PURE__*/ jsx_runtime_.jsx(ProductCard, {
                            title: product.title,
                            hoverTitle: "View product",
                            href: product.href,
                            price: product.price,
                            imageURL: product.imageURL
                        }, idx)
                    )
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "random-names",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            style: {
                                fontWeight: '400'
                            },
                            children: "Random names: "
                        }),
                        randomNames.map((randomName, idx)=>/*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: '/' + encodeURIComponent(randomName),
                                prefetch: false,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    children: randomName
                                })
                            }, `${name}#${idx}`)
                        )
                    ]
                })
            ]
        })
    }));
};


/***/ }),

/***/ 9463:
/***/ ((module) => {

module.exports = require("@hookstate/core");

/***/ }),

/***/ 514:
/***/ ((module) => {

module.exports = require("knex");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 9816:
/***/ ((module) => {

module.exports = require("styled-jsx/style");

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,61,152,990,979], () => (__webpack_exec__(9039)));
module.exports = __webpack_exports__;

})();