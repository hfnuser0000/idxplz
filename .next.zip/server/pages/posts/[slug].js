"use strict";
(() => {
var exports = {};
exports.id = 922;
exports.ids = [922];
exports.modules = {

/***/ 2103:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ShopPage),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./components/templates/layout.jsx + 6 modules
var layout = __webpack_require__(9353);
// EXTERNAL MODULE: ./components/atoms/collection-heading.jsx
var collection_heading = __webpack_require__(9883);
// EXTERNAL MODULE: ./components/molecules/card.jsx
var card = __webpack_require__(8801);
// EXTERNAL MODULE: ./components/atoms/image.jsx
var atoms_image = __webpack_require__(3209);
;// CONCATENATED MODULE: ./components/molecules/product-card.jsx





const Container = (/* unused pure expression or super */ null && (styled.div.withConfig({
    componentId: "sc-161462ee-0"
})`
    position: relative;
    img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        transition: .2s;
    }
    :hover {
        img {
            transform: scale(1.1);
        }
    }

    .card {
        width: 100%;
        background: #7771;
    }

    .product {
        display: flex;
        justify-content: center;
        align-items: center;
        text-align: center;
        background: transparent;
        font-weight: bold;
        font-size: 2rem;
        color: transparent;
        transition: .2s;

        :hover {
            background: #262d24bf;
            color: white;
        }
    }

    .product-title {
        color: #555;
        font-weight: 400;
        display: flex;
        justify-content: center;
        align-items: center;
        text-align: center;
        margin-top: 1rem;
    }

    .price {
        display: block;
        text-align: center;
    }
`));
function ProductCard(props) {
    const { title ="" , hoverTitle , href ="#" , imageURL , ratio =1 , price  } = props;
    return(/*#__PURE__*/ _jsxs(Container, {
        children: [
            /*#__PURE__*/ _jsxs(Card, {
                className: "card",
                ratio: ratio,
                children: [
                    /*#__PURE__*/ _jsx(Link, {
                        href: imageURL,
                        children: /*#__PURE__*/ _jsx("a", {
                            children: /*#__PURE__*/ _jsx("img", {
                                src: imageURL,
                                alt: title
                            })
                        })
                    }),
                    /*#__PURE__*/ _jsx(Link, {
                        href: href,
                        children: /*#__PURE__*/ _jsx("a", {
                            className: "product",
                            children: hoverTitle
                        })
                    })
                ]
            }),
            /*#__PURE__*/ _jsx("a", {
                className: "product-title",
                href: "#",
                children: title
            }),
            price && /*#__PURE__*/ _jsxs("span", {
                className: "price",
                href: "#",
                children: [
                    "only $",
                    price
                ]
            })
        ]
    }));
};

// EXTERNAL MODULE: ./components/atoms/grid.jsx
var grid = __webpack_require__(1056);
;// CONCATENATED MODULE: ./components/molecules/card-collection.jsx


const gridCSS = (/* unused pure expression or super */ null && (`
    grid-template-columns: 1fr 1fr 1fr 1fr;
    @media screen and (max-width: 1200px) {
        grid-template-columns: 1fr 1fr 1fr;
    }
    @media screen and (max-width: 800px) {
        grid-template-columns: 1fr 1fr;
    }
    @media screen and (max-width: 500px) {
        grid-template-columns: 1fr;
    }
`));
function CardCollection(props) {
    return(/*#__PURE__*/ _jsx(Grid, {
        ...props,
        css: gridCSS
    }));
};

// EXTERNAL MODULE: ./components/atoms/post-title.jsx
var post_title = __webpack_require__(4632);
;// CONCATENATED MODULE: ./pages/posts/[slug].jsx










// export async function getStaticProps(context) {
async function getServerSideProps(context) {
    const cmsApi = __webpack_require__(2101);
    const MarkdownIt = __webpack_require__(9653);
    const { slug  } = context.params;
    const md = new MarkdownIt();
    const posts = (await cmsApi.posts.get({
        page: 1,
        populate: '*',
        filters: {
            Slug: slug
        }
    })).data;
    return {
        props: {
            post: posts.data.map((post)=>({
                    title: post.attributes.Title,
                    slug: post.attributes.Slug,
                    content: md.render(post.attributes.Content.replaceAll('(/uploads/', '(https://cms.indexplz.com/uploads/'))
                })
            )[0] ?? null
        }
    };
}
// export async function getStaticPaths() {
//     return {
//         // paths: names,
//         paths: [],
//         fallback: 'blocking'
//     }
// }
const _slug_Container = external_styled_components_default().div.withConfig({
    componentId: "sc-d268d5d3-0"
})`
    img {
        object-fit: contain;
        max-width: 100%;
    }

    .card {
        position: relative;
    }

    .description-card {
        background: #7771;
        margin: 2rem 0;

        > div {
            position: relative;
        }
    }

    .random-names {
        // background: #7771;
        margin: 2rem 0;

        display: flex;
        flex-wrap: wrap;

        > div {
            position: relative;
        }

        p {
            width: 100%;
        }

        a {
            display: inline-block;
            background: #7771;
            padding: .5rem 1rem;
            margin: .5rem;
        }
    }
`;
function ShopPage(props) {
    const { post  } = props;
    let postEl = /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                children: "Uh oh..."
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                children: `Looks like the page has been removed.`
            })
        ]
    });
    if (post) {
        postEl = /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                    href: '/posts/' + post.slug,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(post_title/* default */.Z, {
                            children: post.title
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    dangerouslySetInnerHTML: {
                        __html: post.content
                    }
                })
            ]
        });
    }
    return(/*#__PURE__*/ jsx_runtime_.jsx(layout/* default */.Z, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(_slug_Container, {
            children: postEl
        })
    }));
};


/***/ }),

/***/ 9463:
/***/ ((module) => {

module.exports = require("@hookstate/core");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 9653:
/***/ ((module) => {

module.exports = require("markdown-it");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 7104:
/***/ ((module) => {

module.exports = require("qs");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 9816:
/***/ ((module) => {

module.exports = require("styled-jsx/style");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,61,152,353,395], () => (__webpack_exec__(2103)));
module.exports = __webpack_exports__;

})();