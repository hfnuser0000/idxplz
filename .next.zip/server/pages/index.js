"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 2568:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ HomePage),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./components/layout.jsx + 6 modules
var layout = __webpack_require__(990);
// EXTERNAL MODULE: ./components/collection-heading.jsx
var collection_heading = __webpack_require__(9179);
;// CONCATENATED MODULE: ./components/post-title.jsx

const { default: styled  } = __webpack_require__(7518);
const Container = styled.h1`
    display: inline;
    white-space: pre-wrap;
    font-weight: bold;
    color: #000;
    text-transform: uppercase;
    letter-spacing: .05rem;
    background-image: linear-gradient(#a41fff,#a41fff);
    background-size: .0625rem .3125rem;
    background-repeat: repeat-x;
    background-position: 0 79%;
    text-align: center;
    font-kerning: normal;
`;
function PostTitle(props) {
    return(/*#__PURE__*/ jsx_runtime_.jsx(Container, {
        ...props
    }));
};

// EXTERNAL MODULE: ./components/grid.jsx
var grid = __webpack_require__(4663);
// EXTERNAL MODULE: ./components/image.jsx
var components_image = __webpack_require__(6607);
;// CONCATENATED MODULE: ./public/demo.png
/* harmony default export */ const demo = ({"src":"/_next/static/media/demo.25468062.png","height":640,"width":640,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAclBMVEXp6uvFycacrLbZ4unPv67B2OOTssCtzuHn7vSzubam2Oy2xsfTzsSumIyWxN3Uyb3I5/HAv7imrqrChlOcu8Tbupyf0+fInofp4dfV09O4aUqiTy27oY5aXmK+u64qO0k4R1Ls3cUmIylyl6xmjKOYzOOHrR2TAAAACXBIWXMAAA7DAAAOwwHHb6hkAAAARUlEQVQImQXBBQKAMAwEsJu2c9wd/v9GEhgy9wQAlAnMDND3qrkvCvI5s0yNgdwv6wdfQYjgrO0C4rFp4VyNpNdljLr9AWzQAzXUMWsDAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./pages/index.jsx








async function getStaticProps(context) {
    const MarkdownIt = __webpack_require__(9653);
    const md = new MarkdownIt();
    const demoPageContent = {
        title: '60+ Best Cyber Monday Deals Happening Right Now',
        body: md.render(`
Every year it seems like Black Friday and Cyber Monday deals start earlier and earlier, but this year might just break the record, with so many retailers having launched special savings events for the whole month of November. Get gifts for the [whole family](https://www.bestproducts.com/parenting/kids/g24440535/top-family-gift-ideas/) without worrying about potential shipping delays — and maybe even pick up a few things for the house in time for holiday hosting.
        
Whether you're searching for some new kitchen gadgets for the baker in your life, new tech for the music lovers, or just want to treat yourself to some updated wardrobe staples, we've got you covered this Cyber Monday.
        `)
    };
    return {
        props: {
            pageContent: demoPageContent
        },
        revalidate: 300
    };
}
const pages_Container = external_styled_components_default().div.withConfig({
    componentId: "sc-9d6ff81f-0"
})`
`;
function HomePage(props) {
    const { pageContent  } = props;
    return(/*#__PURE__*/ jsx_runtime_.jsx(layout/* default */.Z, {
        title: "Home",
        children: /*#__PURE__*/ jsx_runtime_.jsx(pages_Container, {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(grid/* default */.Z, {
                templateColumns: "1fr 1fr 1fr 1fr",
                gap: "1rem",
                css: `
                grid-template-areas: "main main main content-table";

                @media screen and (max-width: 1200px) {
                    grid-template-areas: "content-table content-table content-table content-table"
                                         "main main main main";
                }
                `,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        style: {
                            gridArea: 'content-table',
                            background: '#ffd43b',
                            minHeight: '10rem'
                        }
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        style: {
                            gridArea: 'main',
                            justifySelf: 'left'
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(PostTitle, {
                                children: pageContent.title
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(components_image/* default */.Z, {
                                src: "/demo.png"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                dangerouslySetInnerHTML: {
                                    __html: pageContent.body
                                }
                            })
                        ]
                    })
                ]
            })
        })
    }));
};


/***/ }),

/***/ 9463:
/***/ ((module) => {

module.exports = require("@hookstate/core");

/***/ }),

/***/ 9653:
/***/ ((module) => {

module.exports = require("markdown-it");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 9816:
/***/ ((module) => {

module.exports = require("styled-jsx/style");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,61,152,990,979], () => (__webpack_exec__(2568)));
module.exports = __webpack_exports__;

})();