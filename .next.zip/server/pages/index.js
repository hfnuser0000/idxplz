"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 1318:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ HomePage),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./components/templates/layout.jsx + 7 modules
var layout = __webpack_require__(8563);
// EXTERNAL MODULE: ./components/atoms/collection-heading.jsx
var collection_heading = __webpack_require__(9883);
// EXTERNAL MODULE: ./components/atoms/post-title.jsx
var post_title = __webpack_require__(4632);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./components/atoms/image.jsx
var atoms_image = __webpack_require__(3209);
// EXTERNAL MODULE: ./components/molecules/card.jsx
var card = __webpack_require__(8801);
;// CONCATENATED MODULE: ./core/config.json
const config_namespaceObject = {};
;// CONCATENATED MODULE: ./components/molecules/post-card.jsx






const Container = external_styled_components_default().div.withConfig({
    componentId: "sc-30ea9d1b-0"
})`
    a {
        padding: 1rem;
        display: flex;
        flex-direction: column;
        align-items: center;
        margin-bottom: 2rem;
    }

    .thumbnail {
        display: flex;
        min-height: 10rem;

        img {
            object-fit: contain;
            width: 100%;
            height: 100%;
        }
    }

    h2 {
        display: inline;
        white-space: pre-wrap;
        font-weight: bold;
        font-size: .8rem;
        text-transform: uppercase;
        letter-spacing: .05rem;
        text-align: center;
        font-kerning: normal;
        color: #000;
    }
`;
function PostCard(props) {
    let { title , href , thumbnail  } = props;
    return(/*#__PURE__*/ jsx_runtime_.jsx(Container, {
        /*#__PURE__*/ children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
            href: href,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "thumbnail",
                        children: thumbnail && /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: thumbnail
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        children: title
                    })
                ]
            })
        })
    }));
};

// EXTERNAL MODULE: ./components/atoms/grid.jsx
var grid = __webpack_require__(1056);
;// CONCATENATED MODULE: ./pages/index.jsx








async function getServerSideProps(context) {
    const cmsApi = __webpack_require__(2101);
    const posts = (await cmsApi.posts.get({
        page: 1,
        populate: [
            'Thumbnail'
        ],
        fields: [
            'Title',
            'Slug'
        ]
    })).data;
    return {
        props: {
            posts: posts.data.map((post)=>({
                    title: post.attributes.Title,
                    slug: post.attributes.Slug,
                    thumbnail: post.attributes.Thumbnail.data ? "https://cms.indexplz.com" + post.attributes.Thumbnail.data.attributes.formats.thumbnail.url : null
                })
            )
        }
    };
}
const pages_Container = external_styled_components_default().div.withConfig({
    componentId: "sc-8b3ce656-0"
})`
    img {
        object-fit: contain;
        max-width: 100%;
    }
    h1 {
        font-weight: bold;
    }
`;
function HomePage(props) {
    const { pageContent , posts  } = props;
    return(/*#__PURE__*/ jsx_runtime_.jsx(layout/* default */.Z, {
        title: "Home",
        children: /*#__PURE__*/ jsx_runtime_.jsx(pages_Container, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(grid/* default */.Z, {
                templateColumns: "1fr 1fr 1fr 1fr",
                gap: "1rem",
                css: `
                grid-template-areas: "main main main content-table";

                @media screen and (max-width: 1200px) {
                    grid-template-areas: "content-table content-table content-table content-table"
                                         "main main main main";
                }
                `,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    style: {
                        gridArea: 'main',
                        justifySelf: 'left'
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            children: "Recent posts"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(grid/* default */.Z, {
                            gap: "1rem",
                            css: `
                        grid-template-columns: 1fr 1fr 1fr;

                        @media screen and (max-width: 800px) {
                            grid-template-columns: 1fr 1fr;
                        }
                        `,
                            children: posts.map((post, idx)=>/*#__PURE__*/ jsx_runtime_.jsx(PostCard, {
                                    title: post.title,
                                    thumbnail: post.thumbnail,
                                    href: '/posts/' + post.slug,
                                    style: {
                                        gridArea: 'card',
                                        justifySelf: 'left'
                                    }
                                }, idx)
                            )
                        })
                    ]
                })
            })
        })
    }));
};


/***/ }),

/***/ 9463:
/***/ ((module) => {

module.exports = require("@hookstate/core");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 7104:
/***/ ((module) => {

module.exports = require("qs");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 7518:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ }),

/***/ 9816:
/***/ ((module) => {

module.exports = require("styled-jsx/style");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,61,152,563,395], () => (__webpack_exec__(1318)));
module.exports = __webpack_exports__;

})();