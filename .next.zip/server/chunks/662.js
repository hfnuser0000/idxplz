"use strict";
exports.id = 662;
exports.ids = [662];
exports.modules = {

/***/ 7347:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CardCollection)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _grid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4663);


const gridCSS = `
    grid-template-columns: 1fr 1fr 1fr 1fr;
    @media screen and (max-width: 1200px) {
        grid-template-columns: 1fr 1fr 1fr;
    }
    @media screen and (max-width: 800px) {
        grid-template-columns: 1fr 1fr;
    }
    @media screen and (max-width: 500px) {
        grid-template-columns: 1fr;
    }
`;
function CardCollection(props) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_grid__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        ...props,
        css: gridCSS
    }));
};


/***/ }),

/***/ 3352:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Card)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const { default: styled  } = __webpack_require__(7518);
const hoverCSS = `
    :hover {
        border-color: #888;
    }
`;
const Container = styled.div`
    // border-radius: .5rem;
    border: 2px solid transparent;
    ${(props)=>props.hoverEffect ? hoverCSS : ''
}
    ${(props)=>props.background ? 'background: ' + props.background + ';' : ''
}
    ${(props)=>props.ratio ? 'padding-top: ' + 1 / props.ratio * 100 + '%;' : 'padding: 2rem;'
}
    position: relative;
    overflow: hidden;

    > * {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
    }
`;
function Card(props) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Container, {
        ...props
    }));
};


/***/ }),

/***/ 9179:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CollectionHeading)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const { default: styled  } = __webpack_require__(7518);
const Container = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    margin-bottom: 2rem;
    text-align: center;

    > h1 {
        margin-bottom: .5rem;
        display: flex;
        flex-wrap: wrap;
        white-space: pre-wrap;
        justify-content: center;
    }

    > div {
        width: 5rem;
        height: 5px;
        // border-radius: 999px;
        background: #ff7837;
    }
`;
function CollectionHeading(props) {
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                ...props
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            })
        ]
    }));
};


/***/ }),

/***/ 6607:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export default */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5152);


const DynamicNextImage = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_1__["default"])(()=>Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 5675))
, {
    loadableGenerated: {
        webpack: ()=>[
                /*require.resolve*/(5675)
            ]
        ,
        modules: [
            "..\\components\\image.jsx -> " + "next/image"
        ]
    }
});
function Image(props) {
    return(/*#__PURE__*/ _jsx(DynamicNextImage, {
        placeholder: "blur",
        blurDataURL: "data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=",
        layout: "fill",
        objectFit: "cover",
        ...props
    }));
// return <NextImage placeholder="blur" blurDataURL="data:image/gif;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mPc/QUAAnABsVpGlGwAAAAASUVORK5CYII=" layout="fill" objectFit="cover" {...props} />;
};


/***/ }),

/***/ 1542:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ProductCard)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var _image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6607);
/* harmony import */ var _card__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3352);





const Container = styled_components__WEBPACK_IMPORTED_MODULE_1___default().div.withConfig({
    componentId: "sc-dcccf342-0"
})`
    position: relative;
    img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        transition: .2s;
    }
    :hover {
        img {
            transform: scale(1.1);
        }
    }

    .card {
        width: 100%;
        background: #7771;
    }

    .product {
        display: flex;
        justify-content: center;
        align-items: center;
        text-align: center;
        background: transparent;
        font-weight: bold;
        font-size: 2rem;
        color: transparent;
        transition: .2s;

        :hover {
            background: #262d24bf;
            color: white;
        }
    }

    .product-title {
        color: #555;
        font-weight: 400;
        display: flex;
        justify-content: center;
        align-items: center;
        text-align: center;
        margin-top: 1rem;
    }

    .price {
        display: block;
        text-align: center;
    }
`;
function ProductCard(props) {
    const { title ="" , hoverTitle , href ="#" , imageURL , ratio =1 , price  } = props;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Container, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_card__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                className: "card",
                ratio: ratio,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                        href: imageURL,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: imageURL,
                                alt: title
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                        href: href,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            className: "product",
                            children: hoverTitle
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                className: "product-title",
                href: "#",
                children: title
            }),
            price && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "price",
                href: "#",
                children: [
                    "only $",
                    price
                ]
            })
        ]
    }));
};


/***/ }),

/***/ 6907:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const knex = __webpack_require__(514);
const data = {
};
function connect(dbLocation) {
    if (!data[dbLocation]) {
        data[dbLocation] = knex({
            client: 'sqlite3',
            connection: {
                filename: dbLocation
            },
            useNullAsDefault: true
        });
    }
    return data[dbLocation];
}
module.exports = {
    connect
};


/***/ }),

/***/ 2073:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ImageVersion)
/* harmony export */ });
const version = 1;
function ImageVersion() {
    return version;
};


/***/ })

};
;