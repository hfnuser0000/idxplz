"use strict";
exports.id = 738;
exports.ids = [738];
exports.modules = {

/***/ 2738:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const crypto = __webpack_require__(6113);
const { RNG , shuffle  } = __webpack_require__(8214);
const md5 = (content)=>{
    return crypto.createHash('md5').update(content).digest('hex');
};
const generateData = (name)=>{
    // const baseKeywords      = ['T shirts', 'Hoodies', 'Sweatshirts', 'Tank Tops', 'Mugs'];
    const baseKeywords = [
        'T-shirts'
    ];
    const keywords = shuffle(name, JSON.parse(JSON.stringify(baseKeywords)));
    const shortKeywords = keywords.slice(0, 4);
    const baseKeywordsText = baseKeywords.join(', ');
    const keywordsText = keywords.join(', ');
    const shortKeywordsText = shortKeywords.join(', ');
    const siteDescription = `Are you looking for a custom name shirt? We have various designs of custom name printed on ${baseKeywordsText}. Check it now and pick your favorites!`;
    const description = `Are you looking for ${name} custom name shirt? We have various designs of custom name ${name} printed on ${keywordsText}. Check it now and pick your favorites!`;
    return {
        siteDescription,
        description,
        baseKeywordsText,
        keywordsText,
        shortKeywordsText
    };
};
module.exports = {
    generateData
};


/***/ }),

/***/ 8214:
/***/ ((module) => {


function RNG(seed_0) {
    function xmur3(str) {
        for(var i = 0, h = 1779033703 ^ str.length; i < str.length; i++){
            h = Math.imul(h ^ str.charCodeAt(i), 3432918353);
            h = h << 13 | h >>> 19;
        }
        return function() {
            h = Math.imul(h ^ h >>> 16, 2246822507);
            h = Math.imul(h ^ h >>> 13, 3266489909);
            return (h ^= h >>> 16) >>> 0;
        };
    }
    function mulberry32(a) {
        return function() {
            var t = a += 1831565813;
            t = Math.imul(t ^ t >>> 15, t | 1);
            t ^= t + Math.imul(t ^ t >>> 7, t | 61);
            return ((t ^ t >>> 14) >>> 0) / 4294967296;
        };
    }
    function sfc32(a, b, c, d) {
        return function() {
            a >>>= 0;
            b >>>= 0;
            c >>>= 0;
            d >>>= 0;
            var t = a + b | 0;
            a = b ^ b >>> 9;
            b = c + (c << 3) | 0;
            c = c << 21 | c >>> 11;
            d = d + 1 | 0;
            t = t + d | 0;
            c = c + t | 0;
            return (t >>> 0) / 4294967296;
        };
    }
    // Create xmur3 state:
    var seed = xmur3(seed_0);
    // Output four 32-bit hashes to provide the seed for sfc32.
    var rand = sfc32(seed(), seed(), seed(), seed());
    // Output one 32-bit hash to provide the seed for mulberry32.
    var rand = mulberry32(seed());
    return rand;
}
function shuffle(seed, array) {
    let currentIndex = array.length, randomIndex;
    const rand = RNG(seed);
    // While there remain elements to shuffle...
    while(currentIndex != 0){
        // Pick a remaining element...
        randomIndex = Math.floor(rand() * currentIndex);
        currentIndex--;
        // And swap it with the current element.
        [array[currentIndex], array[randomIndex]] = [
            array[randomIndex],
            array[currentIndex]
        ];
    }
    return array;
}
module.exports = {
    RNG,
    shuffle
};


/***/ })

};
;