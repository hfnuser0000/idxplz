"use strict";
exports.id = 395;
exports.ids = [395];
exports.modules = {

/***/ 9883:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export default */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const { default: styled  } = __webpack_require__(7518);
const Container = (/* unused pure expression or super */ null && (styled.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    margin-bottom: 2rem;
    text-align: center;

    > h1 {
        margin-bottom: .5rem;
        display: flex;
        flex-wrap: wrap;
        white-space: pre-wrap;
        justify-content: center;
    }

    > div {
        width: 5rem;
        height: 5px;
        // border-radius: 999px;
        background: #ff7837;
    }
`));
function CollectionHeading(props) {
    return(/*#__PURE__*/ _jsxs(Container, {
        children: [
            /*#__PURE__*/ _jsx("h1", {
                ...props
            }),
            /*#__PURE__*/ _jsx("div", {
            })
        ]
    }));
};


/***/ }),

/***/ 3209:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export default */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5152);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7518);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_2__);



const Container = (/* unused pure expression or super */ null && (styled.img.withConfig({
    componentId: "sc-72e33f20-0"
})`
    object-fit: contain;
    width: 100%;
`));
const DynamicNextImage = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_1__["default"])(()=>Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 5675))
, {
    loadableGenerated: {
        webpack: ()=>[
                /*require.resolve*/(5675)
            ]
        ,
        modules: [
            "..\\components\\atoms\\image.jsx -> " + "next/image"
        ]
    }
});
function Image(props) {
    // return <DynamicNextImage placeholder="blur" blurDataURL="data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=" layout="fill" objectFit="cover" {...props} />;
    // return <NextImage placeholder="blur" blurDataURL="data:image/gif;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mPc/QUAAnABsVpGlGwAAAAASUVORK5CYII=" layout="fill" objectFit="cover" {...props} />;
    return(/*#__PURE__*/ _jsx(Container, {
        ...props
    }));
};


/***/ }),

/***/ 4632:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ PostTitle)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const { default: styled  } = __webpack_require__(7518);
const Container = styled.div`
    display: inline-block;
    margin-bottom: 2rem;

    > h1 {
        display: inline;
        white-space: pre-wrap;
        font-weight: bold;
        color: #000;
        text-transform: uppercase;
        letter-spacing: .05rem;
        background-image: linear-gradient(#a41fff,#a41fff);
        background-size: .0625rem .3125rem;
        background-repeat: repeat-x;
        background-position: 0 79%;
        text-align: center;
        font-kerning: normal;
    }
`;
function PostTitle(props) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Container, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
            ...props
        })
    }));
};


/***/ }),

/***/ 8801:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export default */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const { default: styled  } = __webpack_require__(7518);
const hoverCSS = `
    :hover {
        border-color: #888;
    }
`;
const Container = styled.div`
    // border-radius: .5rem;
    border: 2px solid transparent;
    ${(props)=>props.hoverEffect ? hoverCSS : ''
}
    ${(props)=>props.background ? 'background: ' + props.background + ';' : ''
}
    ${(props)=>props.ratio ? 'padding-top: ' + 1 / props.ratio * 100 + '%;' : 'padding: 2rem;'
}
    position: relative;
    overflow: hidden;

    > * {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
    }
`;
function Card(props) {
    return(/*#__PURE__*/ _jsx(Container, {
        ...props
    }));
};


/***/ }),

/***/ 2101:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const axios = __webpack_require__(2167);
const qs = __webpack_require__(7104);
const token = `a1390b452023bd9bc46fd0678bdda54c2d9bc3cdea7c995113808bde28e8314f108460f2ee4f000cf67bf5be401464b19014a9f030adc9a0e35aa54bc8bac022e7fe0f60d46cbf3112e801536f81d130967aa3b2014a6dc67ee2ea3923b9a266e8cab255c21a4a8d13fd32f4808159ce1db6ec1865e355f0e9971943a6d95a49`;
const endpoint = (parts, ...values)=>{
    /*
    two major ways to use this function:
        1. endpoint`/posts?page=${page}`
        2. endpoint('/post', {page: page})
    */ if (typeof parts == 'object') {
        return 'https://cms.indexplz.com/api' + parts.map((part, idx)=>idx == 0 ? part : values[idx - 1] + part
        ).join('');
    }
    let path = parts;
    let query = values[0];
    if (query) {
        query = qs.stringify(query, {
            encodeValuesOnly: true
        });
        return 'https://cms.indexplz.com/api' + path + '?' + query;
    }
    return 'https://cms.indexplz.com/api' + path;
};
const config = {
    headers: {
        'authority': 'cms.indexplz.com',
        'pragma': 'no-cache',
        'cache-control': 'no-cache',
        'accept': 'application/json',
        'authorization': `Bearer ${token}`
    }
};
const client = axios.create(config);
module.exports = {
    posts: {
        async get ({ page =1 , pageSize =12 , populate , fields , filters ={
        }  }) {
            return await client.get(endpoint('/posts', {
                pagination: {
                    page,
                    pageSize
                },
                populate,
                fields,
                filters: {
                    host_site: {
                        name: {
                            $eq: 'IndexPlz'
                        }
                    },
                    ...filters
                }
            }));
        }
    }
};


/***/ })

};
;