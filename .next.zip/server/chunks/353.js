"use strict";
exports.id = 353;
exports.ids = [353];
exports.modules = {

/***/ 9461:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Button)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const { default: styled  } = __webpack_require__(7518);
const Container = styled.button`
    // border-radius: .5rem;
    border: none;
    outline: none;
    padding: .5rem 1rem;
    user-select: none;
    cursor: pointer;
    ${(props)=>props.background ? 'background: ' + props.background + ';' : ''
}
    :hover {
        color: #000;
        background: #ffd43b;
        --color: #000;
    }
`;
function Button(props) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Container, {
        ...props
    }));
};


/***/ }),

/***/ 1056:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Grid)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const { default: styled  } = __webpack_require__(7518);
const Container = styled.div`
    display: grid;
    ${(props)=>props.gap ? 'grid-gap: ' + props.gap + ';' : ''
}
    ${(props)=>props.columnGap ? 'grid-column-gap: ' + props.columnGap + ';' : ''
}
    ${(props)=>props.rowGap ? 'grid-row-gap: ' + props.rowGap + ';' : ''
}
    ${(props)=>props.templateColumns ? 'grid-template-columns: ' + props.templateColumns + ';' : ''
}
    ${(props)=>props.templateRows ? 'grid-template-rows: ' + props.templateRows + ';' : ''
}
    ${(props)=>props.templateAreas ? 'grid-template-areas: ' + props.templateAreas + ';' : ''
}
    ${(props)=>props.css ? props.css : ''
}
`;
function Grid(props) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Container, {
        ...props
    }));
};


/***/ }),

/***/ 9353:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "styled-jsx/style"
var style_ = __webpack_require__(9816);
var style_default = /*#__PURE__*/__webpack_require__.n(style_);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@hookstate/core"
var core_ = __webpack_require__(9463);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(7518);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./components/atoms/button.jsx
var atoms_button = __webpack_require__(9461);
;// CONCATENATED MODULE: ./components/atoms/icon.jsx


const fontAwesomeSVGs = {
    // fas
    fasBars: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        "aria-hidden": "true",
        focusable: "false",
        "data-prefix": "fas",
        "data-icon": "bars",
        role: "img",
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 448 512",
        className: "svg-inline--fa fa-bars fa-w-14 fa-2x",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            fill: "currentColor",
            d: "M16 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z"
        })
    }),
    fasShoppingCart: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        "aria-hidden": "true",
        focusable: "false",
        "data-prefix": "fas",
        "data-icon": "shopping-cart",
        role: "img",
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 576 512",
        className: "svg-inline--fa fa-shopping-cart fa-w-18 fa-2x",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            fill: "currentColor",
            d: "M528.12 301.319l47.273-208C578.806 78.301 567.391 64 551.99 64H159.208l-9.166-44.81C147.758 8.021 137.93 0 126.529 0H24C10.745 0 0 10.745 0 24v16c0 13.255 10.745 24 24 24h69.883l70.248 343.435C147.325 417.1 136 435.222 136 456c0 30.928 25.072 56 56 56s56-25.072 56-56c0-15.674-6.447-29.835-16.824-40h209.647C430.447 426.165 424 440.326 424 456c0 30.928 25.072 56 56 56s56-25.072 56-56c0-22.172-12.888-41.332-31.579-50.405l5.517-24.276c3.413-15.018-8.002-29.319-23.403-29.319H218.117l-6.545-32h293.145c11.206 0 20.92-7.754 23.403-18.681z"
        })
    }),
    // far
    farShoppingCart: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        "aria-hidden": "true",
        focusable: "false",
        "data-prefix": "far",
        "data-icon": "shopping-cart",
        role: "img",
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 576 512",
        className: "svg-inline--fa fa-shopping-cart fa-w-18 fa-2x",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            fill: "currentColor",
            d: "M551.991 64H144.28l-8.726-44.608C133.35 8.128 123.478 0 112 0H12C5.373 0 0 5.373 0 12v24c0 6.627 5.373 12 12 12h80.24l69.594 355.701C150.796 415.201 144 430.802 144 448c0 35.346 28.654 64 64 64s64-28.654 64-64a63.681 63.681 0 0 0-8.583-32h145.167a63.681 63.681 0 0 0-8.583 32c0 35.346 28.654 64 64 64 35.346 0 64-28.654 64-64 0-18.136-7.556-34.496-19.676-46.142l1.035-4.757c3.254-14.96-8.142-29.101-23.452-29.101H203.76l-9.39-48h312.405c11.29 0 21.054-7.869 23.452-18.902l45.216-208C578.695 78.139 567.299 64 551.991 64zM208 472c-13.234 0-24-10.766-24-24s10.766-24 24-24 24 10.766 24 24-10.766 24-24 24zm256 0c-13.234 0-24-10.766-24-24s10.766-24 24-24 24 10.766 24 24-10.766 24-24 24zm23.438-200H184.98l-31.31-160h368.548l-34.78 160z"
        })
    }),
    fa6thinShoppingCart: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "-5 -5 235 210",
        width: 225,
        height: 200,
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            fill: "#183153",
            stroke: "#183153",
            d: "M25 0H3.13C1.3.26.26 1.3 0 3.13c.26 1.82 1.3 2.86 3.13 3.12h19.53l36.72 141.41c.52 1.56 1.43 2.34 2.73 2.34h131.64c1.82-.26 2.86-1.3 3.13-3.12-.27-1.83-1.31-2.87-3.13-3.13H64.84l-8.2-31.25h133.99c5.98-.26 10.02-3.26 12.1-8.98l21.1-75c.78-4.17 0-7.82-2.35-10.94-2.34-3.13-5.59-4.82-9.76-5.08H30.86L28.13 2.34C27.6.78 26.56 0 25 0Zm7.42 18.75h179.3c4.69.78 6.64 3.39 5.86 7.81l-21.1 75c-1.04 2.87-2.99 4.43-5.85 4.69H55.08ZM50 181.25c.26 5.21 2.08 9.64 5.47 13.28 3.64 3.39 8.07 5.21 13.28 5.47 5.21-.26 9.64-2.08 13.28-5.47 3.39-3.64 5.21-8.07 5.47-13.28-.26-5.21-2.08-9.64-5.47-13.28-3.64-3.39-8.07-5.21-13.28-5.47-5.21.26-9.64 2.08-13.28 5.47-3.39 3.64-5.21 8.07-5.47 13.28Zm18.75 12.5c-3.65 0-6.64-1.17-8.98-3.52-2.35-2.34-3.52-5.33-3.52-8.98 0-3.65 1.17-6.64 3.52-8.98 2.34-2.35 5.33-3.52 8.98-3.52 3.65 0 6.64 1.17 8.98 3.52 2.35 2.34 3.52 5.33 3.52 8.98 0 3.65-1.17 6.64-3.52 8.98-2.34 2.35-5.33 3.52-8.98 3.52ZM200 181.25c-.26-5.21-2.08-9.64-5.47-13.28-3.64-3.39-8.07-5.21-13.28-5.47-5.21.26-9.64 2.08-13.28 5.47-3.39 3.64-5.21 8.07-5.47 13.28.26 5.21 2.08 9.64 5.47 13.28 3.64 3.39 8.07 5.21 13.28 5.47 5.21-.26 9.64-2.08 13.28-5.47 3.39-3.64 5.21-8.07 5.47-13.28Zm-18.75-12.5c3.65 0 6.64 1.17 8.98 3.52 2.35 2.34 3.52 5.33 3.52 8.98 0 3.65-1.17 6.64-3.52 8.98-2.34 2.35-5.33 3.52-8.98 3.52-3.65 0-6.64-1.17-8.98-3.52-2.35-2.34-3.52-5.33-3.52-8.98 0-3.65 1.17-6.64 3.52-8.98 2.34-2.35 5.33-3.52 8.98-3.52Z"
        })
    }),
    fa6solidLocationPin: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "-5 -5 160 210",
        width: "150",
        height: "200",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            fill: "#183153",
            stroke: "#183153",
            d: "M150 75c-.52-21.35-7.81-39.06-21.87-53.12C114.06 7.81 96.35.52 75 0 53.65.52 35.94 7.81 21.88 21.88 7.81 35.94.52 53.65 0 75c.52 11.72 4.69 25.26 12.5 40.63 7.81 15.36 16.8 30.2 26.95 44.53 10.42 14.58 19.14 26.17 26.18 34.76 2.6 3.13 5.72 4.69 9.37 4.69 3.65 0 6.77-1.56 9.38-4.69 7.03-8.59 15.62-20.18 25.78-34.76 10.15-14.33 19.27-29.17 27.34-44.53 7.81-15.37 11.98-28.91 12.5-40.63Z"
        })
    }),
    fa6thinAt: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "-5 -5 210 210",
        width: "200",
        height: "200",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            fill: "#183153",
            stroke: "#183153",
            d: "M81.25 8.2c20.31-3.64 38.8-1.82 55.47 5.47 16.93 7.55 30.6 18.88 41.01 33.99 10.16 15.36 15.37 32.81 15.63 52.34v8.2c0 9.38-2.6 17.84-7.81 25.39-5.47 7.56-12.76 12.5-21.88 14.85-8.85 2.08-16.93 1.69-24.22-1.17-7.55-2.87-13.67-7.3-18.36-13.29-7.81 5.99-16.92 9.12-27.34 9.38-13.54-.26-24.48-5.21-32.81-14.84-8.34-9.38-11.85-21.1-10.55-35.16 1.3-8.07 4.56-15.23 9.77-21.48 4.94-5.99 11.32-10.42 19.14-13.29 12.5-3.9 23.69-3.25 33.59 1.96.78-2.87 2.74-4.43 5.86-4.69h12.5c3.91.52 5.99 2.6 6.25 6.25v46.87c0 4.43 1.56 8.21 4.69 11.33 2.86 2.87 6.51 4.3 10.94 4.3 4.42 0 8.07-1.43 10.93-4.3 3.13-3.12 4.69-6.9 4.69-11.33v-6.25c-.26-18.49-6.12-34.5-17.58-48.04-11.46-13.28-26.3-21.1-44.53-23.44-20.83-1.3-38.54 4.56-53.12 17.58-14.33 13.28-21.75 30.21-22.27 50.78.26 17.71 5.86 32.81 16.8 45.31 10.93 12.24 24.74 19.92 41.4 23.05 6.51 1.3 10.03 5.34 10.55 12.11 0 3.9-1.43 7.03-4.3 9.37-2.6 2.61-5.86 3.65-9.76 3.13-17.19-2.61-32.29-9.25-45.31-19.92-13.03-10.68-22.53-23.96-28.52-39.85-5.99-15.88-7.29-33.07-3.91-51.56 3.91-18.49 12.37-34.37 25.39-47.66C46.88 20.57 62.76 12.11 81.25 8.2Zm12.11 110.55c5.47 0 9.9-1.82 13.28-5.47 3.65-3.38 5.47-7.81 5.47-13.28 0-5.21-1.82-9.64-5.47-13.28-3.65-3.39-8.07-5.21-13.28-5.47-5.21.26-9.64 2.08-13.28 5.47-3.39 3.64-5.21 8.07-5.47 13.28.26 5.47 2.08 9.9 5.47 13.28 3.64 3.65 8.07 5.47 13.28 5.47Z"
        })
    }),
    fa6solidXMark: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "-5 -5 135 210",
        width: 125,
        height: 200,
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            fill: "#183153",
            stroke: "#183153",
            d: "M121.48 141.02 80.08 100l41.4-41.02c2.35-2.6 3.52-5.59 3.52-8.98 0-3.39-1.17-6.38-3.52-8.98-2.6-2.35-5.59-3.52-8.98-3.52-3.39 0-6.38 1.17-8.98 3.52L62.5 82.42l-41.02-41.4c-2.6-2.35-5.59-3.52-8.98-3.52-3.39 0-6.38 1.17-8.98 3.52C1.17 43.62 0 46.61 0 50c0 3.39 1.17 6.38 3.52 8.98L44.92 100l-41.4 41.02C1.17 143.62 0 146.61 0 150c0 3.39 1.17 6.38 3.52 8.98 2.6 2.35 5.59 3.52 8.98 3.52 3.39 0 6.38-1.17 8.98-3.52l41.02-41.4 41.02 41.4c2.6 2.35 5.59 3.52 8.98 3.52 3.39 0 6.38-1.17 8.98-3.52 2.35-2.6 3.52-5.59 3.52-8.98 0-3.39-1.17-6.38-3.52-8.98Z"
        })
    })
};
const Container = external_styled_components_default().div.withConfig({
    componentId: "sc-23f113d5-0"
})`
    > svg {
        width: 100%;
        height: 100%;

        path {
            stroke: var(--color);
            fill: var(--color);
        }
    }
`;
function Icon(props) {
    return(/*#__PURE__*/ jsx_runtime_.jsx(Container, {
        ...props,
        children: fontAwesomeSVGs[props.name]
    }));
};

;// CONCATENATED MODULE: ./public/logo.svg
/* harmony default export */ const logo = ({"src":"/_next/static/media/logo.dd96707f.svg","height":375,"width":375});
;// CONCATENATED MODULE: ./core/global-state.js

const globalState = (0,core_.createState)({
    showSidebar: false
});
/* harmony default export */ const global_state = (globalState);

;// CONCATENATED MODULE: ./components/organisms/navbar.jsx









const navbar_Container = external_styled_components_default().div.withConfig({
    componentId: "sc-b765e1d3-0"
})`
    height: 5rem;
    background: #333;
    display: flex;
    justify-content: center;
    align-items: center;
    position: sticky;
    top: 0;
    width: 100%;
    box-shadow: 0 2px 5px #2222;
    user-select: none;
    padding: 0rem var(--screen-padding);
    z-index: 999;

    :before {
        content: '';
        position: absolute;
        display: block;
        width: 100%;
        height: 15rem;
        top: -15rem;
        left: 0;
        background: #fff;
    }

    > .wrapper {
        flex: 1;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
        max-width: var(--screen-max-width);

        .logo {
            font-size: 2rem;
            position: relative;
            height: 3.5rem;
            width: 3.5rem;
        }

        .nav-links {
            flex: 1;
            display: flex;
            justify-content: flex-end;

            @media screen and (max-width: 1200px) {
                display: none;
            }

            a {
                margin-right: 2rem;
            }
        }
    }

    a {
        transition: .2s;
        :hover {
            color: #ff5a2d;
        }
    }
`;
function Navbar(props) {
    return(/*#__PURE__*/ jsx_runtime_.jsx(navbar_Container, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "wrapper",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                    href: "/",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: "logo",
                        onDragStart: (e)=>e.preventDefault()
                        ,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                            src: logo,
                            alt: "logo",
                            layout: "fill",
                            objectFit: "contain",
                            priority: true
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(atoms_button/* default */.Z, {
                    onClick: (e)=>global_state.showSidebar.set((p)=>!p
                        )
                    ,
                    background: "transparent",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                        name: "fasBars",
                        style: {
                            width: '1.5rem',
                            transform: 'translateY(3px)',
                            fill: '#ffd43b'
                        }
                    })
                })
            ]
        })
    }));
};

// EXTERNAL MODULE: ./components/atoms/grid.jsx
var grid = __webpack_require__(1056);
;// CONCATENATED MODULE: ./components/organisms/sidebar.jsx












const sidebar_Container = external_styled_components_default().div.withConfig({
    componentId: "sc-4b5a958d-0"
})`
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    box-shadow: 0 2px 5px #2222;

    position: fixed;
    left: 0;
    top: 0;
    width: 25rem;
    max-width: 100vw;
    height: 100vh;
    background: #ffd43b;
    transform: translateX(${(props)=>props.show ? '0' : '-100%'
});

    z-index: 999;
    padding: 0rem var(--screen-padding);
    user-select: none;
    transition: .25s;
    
    @media screen and (max-width: 1200px) {
        width: 100%;
    }

    > .sidebar-head {
        width: 100%;
        display: flex;
        justify-content: flex-end;
        align-items: center;
        height: 5rem;
        padding: 0;
    }

    * {
        font-weight: bold;
        color: #000;
    }

    > .wrapper {
        flex: 1;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        align-items: center;
        max-width: var(--screen-max-width);

        .logo {
            font-size: 2rem;
            position: relative;
            height: 3.5rem;
            width: 3.5rem;
        }

        .nav-links {
            flex: 1;
            display: flex;
            justify-content: flex-end;

            @media screen and (max-width: 1200px) {
                display: none;
            }

            a {
                margin-right: 2rem;
            }
        }
    }

    a {
        transition: .2s;
        :hover {
            color: #ff5a2d;
        }
    }
`;
function Sidebar(props) {
    let state = (0,core_.useState)(global_state);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(sidebar_Container, {
        show: state.showSidebar.get(),
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "sidebar-head",
                children: /*#__PURE__*/ jsx_runtime_.jsx(atoms_button/* default */.Z, {
                    onClick: (e)=>global_state.showSidebar.set(false)
                    ,
                    background: "transparent",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                        name: "fa6solidXMark",
                        style: {
                            width: '1.5rem',
                            transform: 'translateY(3px)',
                            fill: '#000'
                        }
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "wrapper"
            })
        ]
    }));
};

;// CONCATENATED MODULE: ./components/organisms/footer.jsx




const footer_Container = external_styled_components_default().footer.withConfig({
    componentId: "sc-3bbf0daf-0"
})`
    display: flex;
    justify-content: center;
    align-items: stretch;
    padding: 2rem var(--screen-padding);
    background: #333;

    * {
        color: #eee;
        font-size: .8rem;
    }

    a {
        font-weight: bold;
    }

    .absolute-footer {
        max-width: var(--screen-max-width);
        width: 100%;
        padding: 1rem 0;
    }

    .contact-wrapper {
        grid-column: span 2;
        display: flex;
        flex-direction: column;
        flex-wrap: wrap;

        a {
            font-weight: unset;
        }
    }

    .contact-line {
        display: inline-flex;
    }

    .grid {
        @media screen and (max-width: 1200px) {
            > .contact-wrapper {
                grid-column: span 1 !important;
            }
            grid-template-columns: 1fr 1fr 1fr;
        }
        @media screen and (max-width: 800px) {
            grid-template-columns: 1fr 1fr;

            > .contact-wrapper {
                grid-column: span 2 !important;
            }
        }
        @media screen and (max-width: 500px) {
            grid-template-columns: 1fr;

            > .contact-wrapper {
                grid-column: span 1 !important;
            }

            .contact-line {
                flex-wrap: wrap;
            }

            .contact-title {
                width: 100% !important;
            }
        }
    }
`;
function Footer(props) {
    return(/*#__PURE__*/ jsx_runtime_.jsx(footer_Container, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "absolute-footer",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("small", {
                        children: "\xa9 2021 Indexplz. "
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("small", {
                        children: "All rights reserved."
                    })
                })
            ]
        })
    }));
};

;// CONCATENATED MODULE: ./components/templates/layout.jsx










const globalCSS = `
    main.main-content {
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    }
`;
const ContentContainer = external_styled_components_default().div.withConfig({
    componentId: "sc-305e304d-0"
})`
    flex: 1;
    display: flex;
    justify-content: center;
    align-item: stretch;
    padding: 2rem var(--screen-padding);

    > * {
        max-width: var(--screen-max-width);
        width: 100%;
    }
`;
function Layout(props) {
    (0,external_react_.useEffect)(()=>{
        window.globalState = global_state;
    }, []);
    const title = props.title ? props.title + ` — indexplz` : 'indexplz';
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            jsx_runtime_.jsx((style_default()), {
                id: globalCSS.__hash,
                /*#__PURE__*/ children: globalCSS
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "preconnect",
                        href: "https://fonts.gstatic.com",
                        crossOrigin: ""
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        charSet: "utf-8"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        httpEquiv: "X-UA-Compatible",
                        content: "IE=edge"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "robots",
                        content: "index,follow"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "googlebot",
                        content: "index,follow"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "title",
                        content: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: props.description
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:type",
                        content: "website"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:url",
                        content: props.url
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:title",
                        content: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:description",
                        content: props.description
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:image",
                        content: props.thumbnail ?? "https://cms.printinix.com/uploads/t_shirt_mockup_50b0640f9c.jpg"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:site_name",
                        content: `indexplz`
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "twitter:url",
                        content: props.url
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "twitter:title",
                        content: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "twitter:description",
                        content: props.description
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "twitter:card",
                        content: "summary_large_image"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "twitter:image",
                        content: props.thumbnail ?? "https://cms.printinix.com/uploads/t_shirt_mockup_50b0640f9c.jpg"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "manifest",
                        href: "/site.webmanifest"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "canonical",
                        href: props.url
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                className: "main-content",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Navbar, {
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Sidebar, {
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(ContentContainer, {
                        children: props.children
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Footer, {
                    })
                ]
            })
        ]
    }));
};


/***/ })

};
;